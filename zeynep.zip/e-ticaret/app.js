const baseURL='https://fakestoreapi.com/'
const Category=document.querySelector('.categories')
const productsGet=document.querySelector('.products')


async function getCategory(){
  let result=await fetch(`${baseURL}products/categories`)
  let categories=await result.json()

  categories.forEach(category => {
    Category.innerHTML+=`
    <div class="category">${category}</div>
    `
    
  })
}

 async function getAllProduct(){
 let result=await fetch(`${baseURL}products/`)
   let products=await result.json()

  let ProductsAll=products.slice(0,12)
   ProductsAll.forEach((product)=>{
    productsGet.innerHTML+=`
     <div class="card" style="width: 18rem;">
    <img class="card-img-top" src="${product.image}" alt="Card image cap">
    <div class="card-body">
       <h5 class="card-id">${product.id}</h5>
       <h5 class="card-title">${product.title}</h5>
      
       <p class="card-text">${product.description}</p>
       <h5 class="card-price">${product.price}$</h5>
     
    </div>
  </div>
    `

  })
  
} 

getCategory()
getAllProduct()


const Btn = document.querySelector('.btn')
const sideBar = document.querySelector('.sidebar')

function toggle() {
  let display = window.getComputedStyle(sideBar).display
  console.log(display)
  
  if(display == 'flex') {
    sideBar.style.display = 'none'
  }
  else if (display == 'none') {
    sideBar.style.display = 'flex'
  }
}